---@type Provider
return {
    github = require "mason.providers.client.gh",
    npm = require "mason.providers.client.npm",
    pypi = require "mason.providers.client.pypi",
}
